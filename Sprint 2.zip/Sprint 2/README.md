# MyApp_Sprint1_Acamica
My App - Sprint #1 - Acamica - Desarrollador Node JS - Nicolas Palermo

# Instrucciones:
- 1) Descargue el codigo
- 2) Una vez descargado abra la consola dentro de la carpeta donde estan los archivos
- 3) Ejecute el comando: npm install
- 4) Se instalara todas las dependencias necesarias para correr el proyecto
- 5) Corra el proyecto con el siguiente comando: nodemon app
- 6) Swagger Documentacion --> http://localhost:8080/api-docs/
